package InstructorPart;

public class InstructorProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MainPage1 hp = new MainPage1();
    }
    
}
